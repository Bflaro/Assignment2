import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import daos.CountryDao;
import entities.Country;
import entities.Database;

//march 14 class continues on from week 8 here
public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Database Project!");

        //SQL Connection in Databse.java
        try (Connection connection = Database.getDataConnection();
        Statement statement = connection.createStatement();	

        )
        {
            List<Country> countryList;
    
            //CountryDoa
            CountryDao countryDao = new CountryDao(connection);
            countryList = countryDao.findAll();
             
              //insert statement
            Country insertCountry = new Country();
            insertCountry.setCode("QUE");
            insertCountry.setName("Quebec");
            insertCountry.setContinent("North America");
            insertCountry.setRegion("North America");
            insertCountry.setSurfaceArea(1668000);
            insertCountry.setIndepYear(2025);
            insertCountry.setPopulation(8400000);
            insertCountry.setLifeExpectancy(84);
            insertCountry.setGNP(4090000);
            insertCountry.setGNPOld(5980000);
            insertCountry.setLocalName("Québec");
            insertCountry.setGovernmentForm("Democracy");
            insertCountry.setHead("Prime Minister");
            insertCountry.setCapital(12);
            insertCountry.setCode2("QU");
            countryDao.insert(insertCountry);
        

            // update / find by id
            Country updateCountry = new Country();
            updateCountry = countryDao.findById("QUE");

            updateCountry.setLifeExpectancy(82);
            countryDao.update(updateCountry);

            System.out.println(updateCountry);

            Boolean success = countryDao.update(updateCountry);

            //delete
            //countryDao.delete("QUE");
           
            
            System.out.println("Countries printed:");
            for(Country country: countryList)
            {
               // System.out.println(country);
            }
        
        } 		
        catch(SQLException ex)
        {
            System.err.println("Exception: " + ex.getMessage());
        }	
    }
}
