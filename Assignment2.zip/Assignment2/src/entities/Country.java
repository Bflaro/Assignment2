package entities;

public class Country {
    String Code;    
    String Name;
    String Continent;
    String Region;
    Float SurfaceArea;
    Integer IndepYear;
    Integer Population;
    Float LifeExpectancy;
    Float GNP;
    Float GNPOld;
    String LocalName;
    String GovernmentForm;
    String HeadofState; 
    Integer Capital;
    String Code2;

    public String getCode()
    {
        return Code;
    }

    public void setCode(String Code)
    {
        this.Code = Code;
    } 

    public String getName()
    {
        return Name;
    }

    public void setName(String Name)
    {
        this.Name = Name;
    } 
    
    public String getContinent()
    {
        return Continent;
    }

    public void setContinent(String Continent)
    {
        this.Continent = Continent;
    }     
    public String getRegion()
    {
        return Region;
    }

    public void setRegion(String Region)
    {
        this.Region = Region;
    } 

    public void setSurfaceArea(float SurfaceArea)
    {
        this.SurfaceArea = SurfaceArea;
    } 

    public float getSurfaceArea()
    {
        return SurfaceArea;
    }

    public void setIndepYear(Integer IndepYear)
    {
        this.IndepYear = IndepYear;
    } 

    public Integer getIndepYear()
    {
        return IndepYear;
    }

    public void setPopulation(Integer Population)
    {
        this.Population = Population;
    } 

    public Integer getPopulation()
    {
        return Population;
    }

    public void setLifeExpectancy(float LifeExpectancy)
    {
        this.LifeExpectancy = LifeExpectancy;
    } 

    public float getLifeExpectancy()
    {
        return LifeExpectancy;
    }

    public String getGovernmentForm()
    {
        return GovernmentForm;
    }

    public void setGovernmentForm(String GovernmentForm)
    {
        this.GovernmentForm = GovernmentForm;
    }   

    public void setGNP(float GNP)
    {
        this.GNP = GNP;
    } 

    public float getGNP()
    {
        return GNP;
    }

    public void setGNPOld(float GNPOld)
    {
        this.GNPOld = GNPOld;
    } 

    public float getGNPOld()
    {
        return GNPOld;
    }

    public void setLocalName(String LocalName)
    {
        this.LocalName = LocalName;
    } 

    public String getLocalName()
    {
        return LocalName;
    }

    public String getHead()
    {
        return HeadofState;
    }

    public void setHead(String HeadofState)
    {
        this.HeadofState = HeadofState;
    } 

    public Integer getCapital()
    {
        return Capital;
    }

    public void setCapital(Integer Capital)
    {
        this.Capital = Capital;
    } 

    public String getCode2()
    {
        return Code2;
    }

    public void setCode2(String Code2)
    {
        this.Code2 = Code2;
    } 

    @Override
    public String toString()
    {
        return "Country -> Code: " + Code + ", Name: " + Name + ", Continent: " + Continent 
            + ", Region: " + Region + ", Surface Area: " + SurfaceArea + ", Indep Year: " + IndepYear  
            + ", Population: " + Population + ", Region: " + Region + ", LifeExpectancy: " + LifeExpectancy
            + ", GovenmnetForm: " + GovernmentForm + ", GNP: " + GNP + ", GNPOld: " + GNPOld 
            + ", Local Name: " + LocalName + ", Head of State: " + HeadofState + ", Capital: " + Capital 
            + ", Code2: " + Code2;
    }
}
